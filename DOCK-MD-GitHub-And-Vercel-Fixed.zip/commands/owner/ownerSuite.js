import { exec } from 'child_process';
import fs from 'fs';
import util from 'util';
import config from '../../config.js';
import { getUserData } from '../../lib/database.js';

const execAsync = util.promisify(exec);

export async function executeOwnerSuite(cmd, sock, m, ctx) {
  const { chatId, args, text, isOwner, quotedParticipant, mentions } = ctx;

  if (cmd === 'pair' || cmd === 'paircode') {
    const phone = (args[0] || '').replace(/[^0-9]/g, '');
    if (!phone || phone.length < 10 || phone.length > 15) {
      return sock.sendMessage(
        chatId,
        { text: `🔗 *${config.botName} PAIRING SYSTEM*\nUsage: \`${config.prefix}${cmd} 923001234567\`\nDefault Custom Code: *${config.customPairCode}*` },
        { quoted: m }
      );
    }
    try {
      const code = await sock.requestPairingCode(phone, config.customPairCode);
      const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
      return sock.sendMessage(
        chatId,
        {
          text:
            `🔐 *${config.botName} PAIRING CODE*\n\n` +
            `📱 *Number:* +${phone}\n` +
            `🔑 *Code:* \`\`\`${formatted}\`\`\`\n\n` +
            `_Open WhatsApp > Linked Devices > Link with phone number and enter the code above._`
        },
        { quoted: m }
      );
    } catch (err) {
      return sock.sendMessage(chatId, { text: config.messages.error(err.message) }, { quoted: m });
    }
  }

  if (!isOwner) {
    return sock.sendMessage(chatId, { text: config.messages.ownerOnly }, { quoted: m });
  }

  const targetUser = quotedParticipant || mentions[0] || (args[0] ? `${args[0].replace(/[^0-9]/g, '')}@s.whatsapp.net` : null);

  if (['ban', 'unban', 'sudo', 'delsudo', 'premium', 'delpremium', 'mod', 'delmod'].includes(cmd)) {
    if (!targetUser) return sock.sendMessage(chatId, { text: '⚠️ Reply to or mention a user.' }, { quoted: m });
    const uData = await getUserData(targetUser);
    if (cmd === 'ban') uData.banned = true;
    if (cmd === 'unban') uData.banned = false;
    if (cmd === 'sudo') uData.sudo = true;
    if (cmd === 'delsudo') uData.sudo = false;
    if (cmd === 'premium') uData.premium = true;
    if (cmd === 'delpremium') uData.premium = false;
    if (cmd === 'mod') uData.mod = true;
    if (cmd === 'delmod') uData.mod = false;
    await uData.save();
    return sock.sendMessage(
      chatId,
      { text: `✅ *${config.botName}:* Updated *${cmd.toUpperCase()}* status for @${targetUser.split('@')[0]}.`, mentions: [targetUser] },
      { quoted: m }
    );
  }

  if (cmd === 'block' || cmd === 'unblock') {
    if (!targetUser) return sock.sendMessage(chatId, { text: '⚠️ Specify a user to block/unblock.' }, { quoted: m });
    await sock.updateBlockStatus(targetUser, cmd === 'block' ? 'block' : 'unblock');
    return sock.sendMessage(chatId, { text: `✅ User @${targetUser.split('@')[0]} ${cmd}ed.`, mentions: [targetUser] }, { quoted: m });
  }

  if (cmd === 'setprefix') {
    if (!args[0]) return sock.sendMessage(chatId, { text: '⚠️ Provide a new prefix symbol.' }, { quoted: m });
    config.prefix = args[0];
    return sock.sendMessage(chatId, { text: `✅ *${config.botName}* prefix changed to: \`${config.prefix}\`` }, { quoted: m });
  }

  if (['setmode', 'privatemode', 'publicmode'].includes(cmd)) {
    const newMode = cmd === 'privatemode' ? 'private' : cmd === 'publicmode' ? 'public' : (args[0] || 'public');
    config.mode = newMode;
    return sock.sendMessage(chatId, { text: `✅ *${config.botName}* mode switched to: *${config.mode.toUpperCase()}*` }, { quoted: m });
  }

  if (cmd === 'setbotname') {
    if (!text) return sock.sendMessage(chatId, { text: '⚠️ Provide a new bot name.' }, { quoted: m });
    config.botName = text;
    return sock.sendMessage(chatId, { text: `✅ Bot identity updated to: *${config.botName}*` }, { quoted: m });
  }

  if (cmd === 'setbio' || cmd === 'setstatus') {
    await sock.updateProfileStatus(text || `${config.botName} - Active 24/7`);
    return sock.sendMessage(chatId, { text: '✅ Bot WhatsApp Bio updated!' }, { quoted: m });
  }

  if (cmd === 'autoread') {
    config.autoRead = !config.autoRead;
    return sock.sendMessage(chatId, { text: `✅ Auto-Read (Blue Ticks): *${config.autoRead ? 'ON' : 'OFF'}*` }, { quoted: m });
  }

  if (cmd === 'alwaysonline') {
    config.autoOnline = !config.autoOnline;
    return sock.sendMessage(chatId, { text: `✅ Always-Online: *${config.autoOnline ? 'ON' : 'OFF'}*` }, { quoted: m });
  }

  if (cmd.startsWith('bc') || cmd.startsWith('broadcast')) {
    if (!text) return sock.sendMessage(chatId, { text: '⚠️ Provide a message to broadcast.' }, { quoted: m });
    const groupsObj = await sock.groupFetchAllParticipating();
    const groupJids = Object.keys(groupsObj);
    let sent = 0;
    for (const jid of groupJids.slice(0, 25)) {
      await sock.sendMessage(jid, { text: `📢 *${config.botName} BROADCAST*\n\n${text}` });
      sent++;
    }
    return sock.sendMessage(chatId, { text: `✅ Broadcast delivered to *${sent}* groups.` }, { quoted: m });
  }

  if (cmd === 'eval') {
    try {
      const result = await eval(`(async () => { ${text} })()`);
      return sock.sendMessage(chatId, { text: `🖥️ *EVAL OUTPUT:*\n\`\`\`${util.inspect(result, { depth: 2 }).slice(0, 3500)}\`\`\`` }, { quoted: m });
    } catch (e) {
      return sock.sendMessage(chatId, { text: config.messages.error(e.message) }, { quoted: m });
    }
  }

  if (cmd === 'shell' || cmd === 'ls') {
    const commandToRun = cmd === 'ls' ? 'ls -la' : text;
    if (!commandToRun) return sock.sendMessage(chatId, { text: '⚠️ Specify a shell command.' }, { quoted: m });
    const { stdout, stderr } = await execAsync(commandToRun);
    return sock.sendMessage(chatId, { text: `💻 *SHELL:*\n\`\`\`${(stdout || stderr || 'Done.').slice(0, 3500)}\`\`\`` }, { quoted: m });
  }

  if (cmd === 'cat') {
    if (!args[0] || !fs.existsSync(args[0])) return sock.sendMessage(chatId, { text: '⚠️ File not found.' }, { quoted: m });
    const content = fs.readFileSync(args[0], 'utf8');
    return sock.sendMessage(chatId, { text: `📄 *${args[0]}:*\n\`\`\`${content.slice(0, 3500)}\`\`\`` }, { quoted: m });
  }

  if (cmd === 'leavegc') {
    await sock.sendMessage(chatId, { text: `👋 *${config.botName}* is leaving the group. Goodbye!` });
    return await sock.groupLeave(chatId);
  }

  if (cmd === 'restart') {
    await sock.sendMessage(chatId, { text: `🔄 Restarting *${config.botName}*...` }, { quoted: m });
    process.exit(0);
  }

  return sock.sendMessage(
    chatId,
    { text: `⚙️ *${config.botName} OWNER PANEL*\nCommand \`${config.prefix}${cmd}\` executed successfully.` },
    { quoted: m }
  );
}
