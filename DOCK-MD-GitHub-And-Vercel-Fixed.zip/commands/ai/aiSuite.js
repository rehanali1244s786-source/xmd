import axios from 'axios';
import config from '../../config.js';

export async function executeAiSuite(cmd, sock, m, ctx) {
  const { chatId, text, quotedText } = ctx;
  const promptInput = text || quotedText;

  if (!promptInput) {
    return sock.sendMessage(
      chatId,
      { text: `🤖 *${config.botName} AI ENGINE*\nUsage: \`${config.prefix}${cmd} <your prompt>\` (or reply to a message).` },
      { quoted: m }
    );
  }

  const imageCommands = [
    'imagegen', 'imagevariation', 'avatargen', 'logogen', 'posterai', 'wallpaperai',
    'sketchai', 'cartoonai', 'realisticai', 'animeai', 'pixelai', 'aiart', 'aiportrait',
    'ailandscape', 'aianime', 'ai3d', 'aiicon', 'aimockup', 'aitattoo', 'aifashion',
    'aihair', 'aimakeup', 'airoom', 'aiinterior', 'aiarchitect', 'aicar', 'aifood',
    'aimonster', 'aipet', 'aifantasy', 'aiscifi', 'aicyberpunk', 'aihorror',
    'aiwatercolor', 'aioil', 'aicharcoal', 'aipencil', 'aimanga', 'aicomic',
    'aiflag', 'aibanner', 'aithumbnail', 'aicover', 'aipfp'
  ];

  if (imageCommands.includes(cmd)) {
    await sock.sendMessage(chatId, { text: config.messages.wait }, { quoted: m });
    const styleTag = cmd.replace(/^ai/, '').replace(/gen$/, '');
    const enhancedPrompt = encodeURIComponent(`${promptInput}, ${styleTag} style, ultra detailed, 8k resolution, masterpiece`);
    const seed = Math.floor(Math.random() * 1000000);
    const imageUrl = `https://image.pollinations.ai/prompt/${enhancedPrompt}?width=1024&height=1024&seed=${seed}&nologo=true`;

    const imgRes = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 30000 });
    return await sock.sendMessage(
      chatId,
      {
        image: Buffer.from(imgRes.data),
        caption: `🎨 *${config.botName} AI STUDIO (${cmd.toUpperCase()})*\n📝 *Prompt:* ${promptInput}`
      },
      { quoted: m }
    );
  }

  const systemInstruction =
    `You are ${config.botName}, an expert AI assistant on WhatsApp. ` +
    `Your current specialized task mode is "${cmd}". ` +
    `Provide a clear, well-structured response formatted for WhatsApp markdown.`;

  let aiReply = '';

  if (config.apis.groq) {
    const res = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model: 'llama-3.3-70b-versatile',
        messages: [
          { role: 'system', content: systemInstruction },
          { role: 'user', content: `Task [${cmd}]: ${promptInput}` }
        ]
      },
      { headers: { Authorization: `Bearer ${config.apis.groq}` }, timeout: 20000 }
    );
    aiReply = res.data?.choices?.[0]?.message?.content;
  } else if (config.apis.openai) {
    const res = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemInstruction },
          { role: 'user', content: `Task [${cmd}]: ${promptInput}` }
        ]
      },
      { headers: { Authorization: `Bearer ${config.apis.openai}` }, timeout: 20000 }
    );
    aiReply = res.data?.choices?.[0]?.message?.content;
  } else {
    const res = await axios.post(
      'https://text.pollinations.ai/',
      {
        messages: [
          { role: 'system', content: systemInstruction },
          { role: 'user', content: `Execute task "${cmd}" on the following input:\n${promptInput}` }
        ],
        model: 'openai'
      },
      { timeout: 25000 }
    );
    aiReply = typeof res.data === 'string' ? res.data : JSON.stringify(res.data);
  }

  return await sock.sendMessage(
    chatId,
    {
      text: `🤖 *${config.botName} - ${cmd.toUpperCase()}*\n\n${aiReply.trim()}`
    },
    { quoted: m }
  );
}
