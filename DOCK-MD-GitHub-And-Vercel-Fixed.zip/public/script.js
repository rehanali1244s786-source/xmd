document.addEventListener('DOMContentLoaded', () => {
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const closeDrawerBtn = document.getElementById('closeDrawerBtn');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const serverSelect = document.getElementById('serverSelect');
  const serverLimitBadge = document.getElementById('serverLimitBadge');
  const instructionToggle = document.getElementById('instructionToggle');
  const instructionContent = document.getElementById('instructionContent');
  const instructionChevron = document.getElementById('instructionChevron');
  const pairForm = document.getElementById('pairForm');
  const phoneInput = document.getElementById('phoneInput');
  const generateBtn = document.getElementById('generateBtn');
  const btnText = document.getElementById('btnText');
  const btnLoader = document.getElementById('btnLoader');
  const pairModal = document.getElementById('pairModal');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const pairCodeOutput = document.getElementById('pairCodeOutput');
  const copyCodeBtn = document.getElementById('copyCodeBtn');
  const toastContainer = document.getElementById('toastContainer');

  let currentRawCode = 'DOCKWIDE';

  function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.remove();
    }, 4000);
  }

  hamburgerBtn.addEventListener('click', () => mobileDrawer.classList.add('open'));
  closeDrawerBtn.addEventListener('click', () => mobileDrawer.classList.remove('open'));
  document.querySelectorAll('.drawer-link').forEach((link) => {
    link.addEventListener('click', () => mobileDrawer.classList.remove('open'));
  });

  serverSelect.addEventListener('change', (e) => {
    const selectedOption = e.target.options[e.target.selectedIndex];
    const limitText = selectedOption.getAttribute('data-limit') || '10 / 50';
    serverLimitBadge.textContent = `Limit: ${limitText}`;
    showToast(`Switched to ${selectedOption.text.split('—')[0].trim()}`, 'success');
  });

  instructionToggle.addEventListener('click', () => {
    const isOpen = instructionContent.classList.toggle('open');
    instructionChevron.textContent = isOpen ? '▲' : '▼';
  });

  phoneInput.addEventListener('input', () => {
    phoneInput.value = phoneInput.value.replace(/[^0-9]/g, '');
  });

  pairForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const cleanedNumber = phoneInput.value.replace(/[^0-9]/g, '');

    if (cleanedNumber.length < 10 || cleanedNumber.length > 15) {
      showToast('⚠️ Please enter a valid 10 to 15 digit WhatsApp number with country code (e.g., 923001234567).', 'error');
      phoneInput.focus();
      return;
    }

    generateBtn.disabled = true;
    btnText.textContent = 'Generating Code...';
    btnLoader.classList.remove('hidden');

    try {
      const response = await fetch('/api/pair', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          number: cleanedNumber,
          server: serverSelect.value
        })
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || 'Failed to generate pairing code.');
      }

      currentRawCode = data.rawCode || 'DOCKWIDE';
      pairCodeOutput.textContent = data.code || 'DOCK-WIDE';
      pairModal.classList.remove('hidden');
      showToast('✅ Pairing code generated successfully!', 'success');
    } catch (err) {
      showToast(`❌ ${err.message}`, 'error');
    } finally {
      generateBtn.disabled = false;
      btnText.textContent = '⚡ Generate Pair Code';
      btnLoader.classList.add('hidden');
    }
  });

  copyCodeBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(currentRawCode);
      showToast(`📋 Copied "${currentRawCode}" to clipboard!`, 'success');
    } catch {
      showToast('❌ Unable to copy automatically. Please copy manually.', 'error');
    }
  });

  closeModalBtn.addEventListener('click', () => pairModal.classList.add('hidden'));
  pairModal.addEventListener('click', (e) => {
    if (e.target === pairModal) pairModal.classList.add('hidden');
  });
});
