import crypto from 'crypto';
import axios from 'axios';
import sharp from 'sharp';
import QRCode from 'qrcode';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import config from '../../config.js';

async function getQuotedOrDirectImage(m) {
  const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const img = m.message?.imageMessage || quoted?.imageMessage;
  const stk = quoted?.stickerMessage;
  const target = img || stk;
  const type = img ? 'image' : stk ? 'sticker' : null;
  if (!target) return null;
  const stream = await downloadContentFromMessage(target, type);
  const chunks = [];
  for await (const c of stream) chunks.push(c);
  return Buffer.concat(chunks);
}

export async function executeToolsSuite(cmd, sock, m, ctx) {
  const { chatId, text, args, quotedText } = ctx;
  const input = text || quotedText || '';

  const imageFilterCmds = [
    'sticker', 'sticker2', 'stickercrop', 'stickerfull', 'tosticker', 'toimg',
    'grayscale', 'invert', 'mirror', 'flip', 'rotate', 'blurimg', 'sharpen',
    'brighten', 'darken', 'pixelate', 'thumbnail', 'resize'
  ];

  if (imageFilterCmds.includes(cmd) || cmd.endsWith('sticker')) {
    const mediaBuf = await getQuotedOrDirectImage(m);
    if (!mediaBuf) {
      return sock.sendMessage(chatId, { text: `⚠️ Reply to an image or sticker with \`${config.prefix}${cmd}\`.` }, { quoted: m });
    }

    if (cmd === 'toimg') {
      const pngBuf = await sharp(mediaBuf).png().toBuffer();
      return sock.sendMessage(chatId, { image: pngBuf, caption: `🖼️ Converted by *${config.botName}*` }, { quoted: m });
    }

    if (cmd.includes('sticker')) {
      const webpBuf = await sharp(mediaBuf)
        .resize(512, 512, { fit: cmd === 'stickercrop' ? 'cover' : 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .webp({ quality: 85 })
        .toBuffer();
      return sock.sendMessage(chatId, { sticker: webpBuf }, { quoted: m });
    }

    let pipeline = sharp(mediaBuf);
    if (cmd === 'grayscale') pipeline = pipeline.grayscale();
    if (cmd === 'invert') pipeline = pipeline.negate();
    if (cmd === 'mirror') pipeline = pipeline.flop();
    if (cmd === 'flip') pipeline = pipeline.flip();
    if (cmd === 'rotate') pipeline = pipeline.rotate(parseInt(args[0], 10) || 90);
    if (cmd === 'blurimg') pipeline = pipeline.blur(8);
    if (cmd === 'sharpen') pipeline = pipeline.sharpen();
    if (cmd === 'brighten') pipeline = pipeline.modulate({ brightness: 1.4 });
    if (cmd === 'darken') pipeline = pipeline.modulate({ brightness: 0.6 });
    if (cmd === 'pixelate') pipeline = pipeline.resize(64, 64, { kernel: 'nearest' }).resize(512, 512, { kernel: 'nearest' });
    if (cmd === 'thumbnail' || cmd === 'resize') pipeline = pipeline.resize(300, 300, { fit: 'cover' });

    const outBuf = await pipeline.jpeg({ quality: 90 }).toBuffer();
    return sock.sendMessage(chatId, { image: outBuf, caption: `✨ *${config.botName}* Filter: *${cmd}*` }, { quoted: m });
  }

  if (cmd === 'qrcode' || cmd === 'barcode') {
    if (!input) return sock.sendMessage(chatId, { text: '⚠️ Provide text or URL to encode into a QR Code.' }, { quoted: m });
    const qrBuffer = await QRCode.toBuffer(input, { width: 512, margin: 2 });
    return sock.sendMessage(chatId, { image: qrBuffer, caption: `🏁 *${config.botName} QR CODE*\nContent: \`${input}\`` }, { quoted: m });
  }

  if (cmd === 'uuid') {
    return sock.sendMessage(chatId, { text: `🆔 *UUID v4:*\n\`\`\`${crypto.randomUUID()}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'passgen') {
    const len = Math.min(Math.max(parseInt(args[0], 10) || 16, 8), 64);
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+';
    const pass = Array.from(crypto.randomBytes(len)).map((b) => chars[b % chars.length]).join('');
    return sock.sendMessage(chatId, { text: `🔐 *Generated Password (${len} chars):*\n\`\`\`${pass}\`\`\`` }, { quoted: m });
  }
  if (['md5', 'sha1', 'sha256', 'sha512'].includes(cmd)) {
    if (!input) return sock.sendMessage(chatId, { text: '⚠️ Provide text to hash.' }, { quoted: m });
    const hash = crypto.createHash(cmd).update(input).digest('hex');
    return sock.sendMessage(chatId, { text: `🔒 *${cmd.toUpperCase()} HASH:*\n\`\`\`${hash}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'base64enc') {
    return sock.sendMessage(chatId, { text: `📦 *Base64 Encoded:*\n\`\`\`${Buffer.from(input).toString('base64')}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'base64dec') {
    return sock.sendMessage(chatId, { text: `📦 *Base64 Decoded:*\n\`\`\`${Buffer.from(input, 'base64').toString('utf8')}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'hexenc') {
    return sock.sendMessage(chatId, { text: `📦 *Hex Encoded:*\n\`\`\`${Buffer.from(input).toString('hex')}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'hexdec') {
    return sock.sendMessage(chatId, { text: `📦 *Hex Decoded:*\n\`\`\`${Buffer.from(input, 'hex').toString('utf8')}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'binaryenc') {
    const bin = input.split('').map((c) => c.charCodeAt(0).toString(2).padStart(8, '0')).join(' ');
    return sock.sendMessage(chatId, { text: `💻 *Binary:*\n\`\`\`${bin}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'binarydec') {
    const str = input.split(/\s+/).map((b) => String.fromCharCode(parseInt(b, 2))).join('');
    return sock.sendMessage(chatId, { text: `💻 *Decoded Text:*\n\`\`\`${str}\`\`\`` }, { quoted: m });
  }
  if (cmd === 'urlenc') {
    return sock.sendMessage(chatId, { text: encodeURIComponent(input) }, { quoted: m });
  }
  if (cmd === 'urldec') {
    return sock.sendMessage(chatId, { text: decodeURIComponent(input) }, { quoted: m });
  }
  if (cmd === 'rot13') {
    const out = input.replace(/[a-zA-Z]/g, (c) => String.fromCharCode((c <= 'Z' ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26));
    return sock.sendMessage(chatId, { text: `🔄 *ROT13:*\n\`${out}\`` }, { quoted: m });
  }

  if (cmd === 'uppercase') return sock.sendMessage(chatId, { text: input.toUpperCase() }, { quoted: m });
  if (cmd === 'lowercase') return sock.sendMessage(chatId, { text: input.toLowerCase() }, { quoted: m });
  if (cmd === 'reverse') return sock.sendMessage(chatId, { text: input.split('').reverse().join('') }, { quoted: m });
  if (cmd === 'wordcount') return sock.sendMessage(chatId, { text: `📊 *Word Count:* ${input.trim().split(/\s+/).filter(Boolean).length}` }, { quoted: m });
  if (cmd === 'charcount') return sock.sendMessage(chatId, { text: `📊 *Character Count:* ${input.length}` }, { quoted: m });
  if (cmd === 'slugify') return sock.sendMessage(chatId, { text: input.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') }, { quoted: m });

  if (cmd === 'ipinfo') {
    const ip = args[0] || '';
    const { data } = await axios.get(`http://ip-api.com/json/${ip}`);
    return sock.sendMessage(
      chatId,
      {
        text:
          `🌐 *${config.botName} IP LOOKUP*\n` +
          `📍 *IP:* ${data.query}\n` +
          `🏳️ *Country:* ${data.country} (${data.countryCode})\n` +
          `🏙️ *City:* ${data.city}, ${data.regionName}\n` +
          `📡 *ISP:* ${data.isp}\n` +
          `🕒 *Timezone:* ${data.timezone}`
      },
      { quoted: m }
    );
  }

  if (cmd === 'dnslookup') {
    const domain = args[0] || 'google.com';
    const { data } = await axios.get(`https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=A`);
    const ips = (data.Answer || []).map((a) => a.data).join(', ') || 'No A records found';
    return sock.sendMessage(chatId, { text: `🔍 *DNS Lookup (${domain}):*\n\`${ips}\`` }, { quoted: m });
  }

  return sock.sendMessage(
    chatId,
    { text: `🛠️ *${config.botName} TOOLBOX (${cmd.toUpperCase()})*\nProcessed input: \`${input || 'Ready'}\`` },
    { quoted: m }
  );
}
