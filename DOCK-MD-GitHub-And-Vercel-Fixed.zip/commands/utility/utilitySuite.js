import os from 'os';
import axios from 'axios';
import config from '../../config.js';
import { getUserData } from '../../lib/database.js';
import { getAllLoadedCommands } from '../../lib/registry.js';

export async function executeUtilitySuite(cmd, sock, m, ctx) {
  const { chatId, text, args, senderJid } = ctx;

  if (cmd.endsWith('menu') || ['help', 'commands', 'cmdlist', 'categories'].includes(cmd)) {
    const allCmds = getAllLoadedCommands();
    const uptimeSec = Math.floor(process.uptime());
    const hours = Math.floor(uptimeSec / 3600);
    const mins = Math.floor((uptimeSec % 3600) / 60);

    if (cmd === 'allmenu' || cmd === 'menuall' || cmd === 'cmdlist') {
      const sample = Array.from(allCmds).slice(0, 400).map((c) => `${config.prefix}${c}`).join(', ');
      return sock.sendMessage(
        chatId,
        {
          text:
            `╭━━━〔 *${config.botName} FULL REGISTRY* 〕━━━┈⊷\n` +
            `┃ ⚡ *Total Commands:* ${allCmds.size}\n` +
            `┃ 🔑 *Pair Code:* ${config.customPairCode}\n` +
            `╰━━━━━━━━━━━━━━━━━━┈⊷\n\n` +
            `${sample}\n\n_...and ${allCmds.size - 400} more commands active! Use ${config.prefix}cmdsearch <keyword> to filter._`
        },
        { quoted: m }
      );
    }

    const menuText =
      `╭━━━〔 *${config.botName} COMMAND CENTER* 〕━━━┈⊷\n` +
      `┃ 👤 *User:* @${senderJid.split('@')[0]}\n` +
      `┃ ⚡ *Prefix:* [ ${config.prefix} ]\n` +
      `┃ 🌐 *Mode:* ${config.mode.toUpperCase()}\n` +
      `┃ ⏱️ *Uptime:* ${hours}h ${mins}m\n` +
      `┃ 📦 *Commands Loaded:* ${allCmds.size}\n` +
      `┃ 🔐 *Pair Code:* ${config.customPairCode}\n` +
      `╰━━━━━━━━━━━━━━━━━━━━━━┈⊷\n\n` +
      `┌──『 *📂 COMMAND SUITES* 』\n` +
      `│ 👑 *Owner:* \`.dp\`, \`.pair\`, \`.ban\`, \`.broadcast\`, \`.setprefix\`\n` +
      `│ 🛡️ *Group:* \`.tagall\`, \`.hidetag\`, \`.kick\`, \`.antilink\`, \`.poll\`\n` +
      `│ 🤖 *AI Studio:* \`.gpt\`, \`.gemini\`, \`.imagegen\`, \`.codewrite\`\n` +
      `│ 📥 *Downloader:* \`.ytmp3\`, \`.ytmp4\`, \`.tiktok\`, \`.gitclonedl\`\n` +
      `│ 🛠️ *Tools:* \`.sticker\`, \`.toimg\`, \`.qrcode\`, \`.ipinfo\`, \`.sha256\`\n` +
      `│ 🕌 *Islamic:* \`.quran\`, \`.ayah\`, \`.prayertime\`, \`.hadith\`, \`.dua\`\n` +
      `│ 💰 *Crypto:* \`.btcprice\`, \`.ethprice\`, \`.solprice\`, \`.bnbprice\`\n` +
      `│ 🎮 *Fun & Anime:* \`.waifu\`, \`.anime\`, \`.joke\`, \`.3dneontext\`\n` +
      `│ 🌍 *Translator:* \`.translateurdu\`, \`.translatearabic\`, \`.tts\`\n` +
      `└───────────────┈⊷\n` +
      `_Type ${config.prefix}allmenu to view all ${allCmds.size} commands._`;

    return sock.sendMessage(chatId, { text: menuText, mentions: [senderJid] }, { quoted: m });
  }

  if (cmd === 'cmdsearch') {
    if (!text) return sock.sendMessage(chatId, { text: '⚠️ Specify a keyword to search commands.' }, { quoted: m });
    const matches = Array.from(getAllLoadedCommands()).filter((c) => c.includes(text.toLowerCase()));
    return sock.sendMessage(
      chatId,
      { text: `🔍 *Found ${matches.length} commands matching "${text}":*\n${matches.map((c) => `${config.prefix}${c}`).join(', ') || 'None'}` },
      { quoted: m }
    );
  }

  if (['ping', 'ping3', 'botping', 'pingms', 'latency', 'speedcheck'].includes(cmd)) {
    const start = Date.now();
    await sock.sendPresenceUpdate('composing', chatId);
    const lat = Date.now() - start;
    return sock.sendMessage(chatId, { text: `⚡ *${config.botName} PONG!*\n📡 *Response Speed:* \`${lat} ms\`` }, { quoted: m });
  }

  if (['alive', 'botstatus', 'sysinfo', 'runtime', 'uptime', 'ram', 'cpu', 'status', 'stats', 'serverstats'].includes(cmd)) {
    const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const freeMem = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
    const up = Math.floor(process.uptime());
    return sock.sendMessage(
      chatId,
      {
        text:
          `🤖 *${config.botName} SYSTEM STATUS*\n\n` +
          `⏱️ *Uptime:* ${Math.floor(up / 3600)}h ${Math.floor((up % 3600) / 60)}m ${up % 60}s\n` +
          `💾 *RAM:* ${(totalMem - freeMem).toFixed(2)} GB / ${totalMem} GB\n` +
          `🖥️ *CPU:* ${os.cpus()[0]?.model || 'Cloud vCPU'}\n` +
          `⚙️ *Platform:* ${os.platform()} (${os.arch()})\n` +
          `🟢 *Engine:* Baileys Multi-Device`
      },
      { quoted: m }
    );
  }

  if (['weather', 'forecast', 'humidity', 'wind', 'sunrise', 'sunset'].includes(cmd)) {
    const city = text || 'Lahore';
    const { data } = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=j1`, { timeout: 10000 });
    const cur = data.current_condition?.[0];
    return sock.sendMessage(
      chatId,
      {
        text:
          `🌦️ *${config.botName} WEATHER - ${city.toUpperCase()}*\n\n` +
          `🌡️ *Temp:* ${cur?.temp_C}°C (Feels like ${cur?.FeelsLikeC}°C)\n` +
          `☁️ *Condition:* ${cur?.weatherDesc?.[0]?.value}\n` +
          `💧 *Humidity:* ${cur?.humidity}%\n` +
          `💨 *Wind:* ${cur?.windspeedKmph} km/h\n` +
          `☀️ *UV Index:* ${cur?.uvIndex}`
      },
      { quoted: m }
    );
  }

  if (cmd.endsWith('price')) {
    const symbol = cmd.replace('price', '').toUpperCase();
    try {
      const { data } = await axios.get(`https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol}USDT`, { timeout: 10000 });
      const change = parseFloat(data.priceChangePercent).toFixed(2);
      return sock.sendMessage(
        chatId,
        {
          text:
            `💹 *${config.botName} CRYPTO TRACKER*\n\n` +
            `🪙 *Asset:* ${symbol} / USDT\n` +
            `💵 *Price:* $${parseFloat(data.lastPrice).toLocaleString()}\n` +
            `📈 *24h Change:* ${change >= 0 ? '+' : ''}${change}%\n` +
            `⬆️ *24h High:* $${parseFloat(data.highPrice).toLocaleString()}\n` +
            `⬇️ *24h Low:* $${parseFloat(data.lowPrice).toLocaleString()}`
        },
        { quoted: m }
      );
    } catch {
      return sock.sendMessage(chatId, { text: `💹 *${symbol}:* Market pair is stable ($1.00 USD or unlisted on spot).` }, { quoted: m });
    }
  }

  if (['prayertime', 'fajr', 'dhuhr', 'asr', 'maghrib', 'isha', 'sehri', 'iftar', 'hijri', 'islamicdate'].includes(cmd)) {
    const city = text || 'Lahore';
    const { data } = await axios.get(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=Pakistan&method=1`);
    const t = data.data.timings;
    const hijri = data.data.date.hijri;
    return sock.sendMessage(
      chatId,
      {
        text:
          `🕌 *${config.botName} PRAYER TIMINGS (${city.toUpperCase()})*\n` +
          `📅 *Hijri Date:* ${hijri.day} ${hijri.month.en} ${hijri.year} AH\n\n` +
          `🌅 *Fajr (Sehri):* ${t.Fajr}\n` +
          `☀️ *Sunrise:* ${t.Sunrise}\n` +
          `🕛 *Dhuhr:* ${t.Dhuhr}\n` +
          `🌤️ *Asr:* ${t.Asr}\n` +
          `🌇 *Maghrib (Iftar):* ${t.Maghrib}\n` +
          `🌙 *Isha:* ${t.Isha}`
      },
      { quoted: m }
    );
  }

  if (['quran', 'surah', 'ayah', 'randomayah', 'ayahtranslation', 'ayatkursi', 'dailyayah'].includes(cmd)) {
    const ref = cmd === 'ayatkursi' ? '2:255' : text || String(Math.floor(Math.random() * 6236) + 1);
    const { data } = await axios.get(`https://api.alquran.cloud/v1/ayah/${encodeURIComponent(ref)}/editions/quran-uthmani,en.asad`);
    const arabic = data.data?.[0];
    const english = data.data?.[1];
    return sock.sendMessage(
      chatId,
      {
        text:
          `📖 *${config.botName} AL-QURAN*\n` +
          `📌 *Surah:* ${arabic.surah.englishName} (${arabic.surah.number}:${arabic.numberInSurah})\n\n` +
          `${arabic.text}\n\n` +
          `📝 *Translation:* _"${english.text}"_`
      },
      { quoted: m }
    );
  }

  if (cmd.startsWith('dua') || cmd.startsWith('azkar') || cmd.startsWith('hadith') || cmd.startsWith('prophet') || cmd.startsWith('sahaba')) {
    const res = await axios.post('https://text.pollinations.ai/', {
      messages: [
        { role: 'system', content: `You are ${config.botName} Islamic Scholar Assistant. Provide authentic Arabic text, transliteration, and English/Urdu explanation.` },
        { role: 'user', content: `Provide authentic Islamic details for command: ${cmd} ${text}` }
      ],
      model: 'openai'
    });
    return sock.sendMessage(chatId, { text: `🕌 *${config.botName} ISLAMIC HUB (${cmd.toUpperCase()})*\n\n${res.data}` }, { quoted: m });
  }

  if (cmd === 'wiki') {
    const query = text || 'Pakistan';
    const { data } = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`);
    return sock.sendMessage(chatId, { text: `📚 *WIKIPEDIA: ${data.title}*\n\n${data.extract}\n🔗 ${data.content_urls?.desktop?.page || ''}` }, { quoted: m });
  }

  if (cmd === 'dict' || cmd === 'define') {
    if (!args[0]) return sock.sendMessage(chatId, { text: '⚠️ Specify a word to define.' }, { quoted: m });
    const { data } = await axios.get(`${config.apis.dictionary}/${encodeURIComponent(args[0])}`);
    const entry = data[0];
    const def = entry.meanings?.[0]?.definitions?.[0]?.definition;
    return sock.sendMessage(chatId, { text: `📖 *DICTIONARY: ${entry.word}*\n🗣️ *Phonetic:* ${entry.phonetic || 'N/A'}\n📝 *Definition:* ${def}` }, { quoted: m });
  }

  if (cmd === 'country' || cmd === 'capital' || cmd === 'currencyinfo') {
    const name = text || 'Pakistan';
    const { data } = await axios.get(`https://restcountries.com/v3.1/name/${encodeURIComponent(name)}`);
    const c = data[0];
    return sock.sendMessage(
      chatId,
      {
        text:
          `🏳️ *COUNTRY: ${c.name.common} ${c.flag}*\n` +
          `🏛️ *Capital:* ${c.capital?.[0]}\n` +
          `👥 *Population:* ${c.population.toLocaleString()}\n` +
          `🌍 *Region:* ${c.region} (${c.subregion})\n` +
          `📞 *Dial Code:* ${c.idd?.root}${c.idd?.suffixes?.[0] || ''}`
      },
      { quoted: m }
    );
  }

  if (cmd === 'github' || cmd === 'ghuser') {
    const user = args[0] || 'torvalds';
    const { data } = await axios.get(`https://api.github.com/users/${encodeURIComponent(user)}`);
    return sock.sendMessage(
      chatId,
      {
        text:
          `🐙 *GITHUB USER: ${data.login}*\n` +
          `👤 *Name:* ${data.name || 'N/A'}\n` +
          `📝 *Bio:* ${data.bio || 'N/A'}\n` +
          `📦 *Public Repos:* ${data.public_repos}\n` +
          `👥 *Followers:* ${data.followers} | *Following:* ${data.following}\n` +
          `🔗 ${data.html_url}`
      },
      { quoted: m }
    );
  }

  if (['calc', 'sqrt', 'cbrt', 'sin', 'cos', 'tan', 'log', 'ln', 'abs', 'ceil', 'floor', 'round', 'factorial', 'bmi'].includes(cmd)) {
    const num = parseFloat(args[0]) || 0;
    let resVal = 0;
    if (cmd === 'sqrt') resVal = Math.sqrt(num);
    else if (cmd === 'cbrt') resVal = Math.cbrt(num);
    else if (cmd === 'sin') resVal = Math.sin(num);
    else if (cmd === 'cos') resVal = Math.cos(num);
    else if (cmd === 'tan') resVal = Math.tan(num);
    else if (cmd === 'log') resVal = Math.log10(num);
    else if (cmd === 'ln') resVal = Math.log(num);
    else if (cmd === 'abs') resVal = Math.abs(num);
    else if (cmd === 'ceil') resVal = Math.ceil(num);
    else if (cmd === 'floor') resVal = Math.floor(num);
    else if (cmd === 'round') resVal = Math.round(num);
    else if (cmd === 'factorial') {
      resVal = 1;
      for (let i = 2; i <= Math.min(num, 170); i++) resVal *= i;
    } else if (cmd === 'bmi') {
      const weightKg = parseFloat(args[0]) || 70;
      const heightM = parseFloat(args[1]) || 1.75;
      resVal = (weightKg / (heightM * heightM)).toFixed(2);
    } else if (cmd === 'calc') {
      const sanitized = (text || '0').replace(/[^0-9+\-*/().%^ ]/g, '');
      resVal = Function(`"use strict"; return (${sanitized})`)();
    }
    return sock.sendMessage(chatId, { text: `🧮 *${config.botName} MATH (${cmd.toUpperCase()})*\nResult: *${resVal}*` }, { quoted: m });
  }

  const uData = await getUserData(senderJid);
  if (cmd.startsWith('afk')) {
    uData.afk = cmd !== 'afkoff' && cmd !== 'back';
    uData.afkReason = text || 'Busy right now';
    uData.afkTime = Date.now();
    await uData.save();
    return sock.sendMessage(chatId, { text: `💤 @${senderJid.split('@')[0]} is now *${uData.afk ? 'AFK' : 'Back Online'}* (${uData.afkReason})`, mentions: [senderJid] }, { quoted: m });
  }

  if (cmd === 'addtodo' || cmd === 'todo' || cmd === 'deltodo') {
    if (cmd === 'addtodo' && text) {
      uData.todos.push({ task: text, done: false });
      await uData.save();
    }
    if (cmd === 'deltodo') {
      uData.todos.splice((parseInt(args[0], 10) || 1) - 1, 1);
      await uData.save();
    }
    const list = uData.todos.map((t, i) => `${i + 1}. ${t.done ? '✅' : '⬜'} ${t.task}`).join('\n') || 'Empty todo list.';
    return sock.sendMessage(chatId, { text: `📝 *YOUR TODO LIST:*\n${list}` }, { quoted: m });
  }

  const res = await axios.post('https://text.pollinations.ai/', {
    messages: [
      { role: 'system', content: `You are ${config.botName}. Provide a concise, accurate response for the utility/sports/education command.` },
      { role: 'user', content: `Command: ${cmd} | Input: ${text || 'Provide latest overview'}` }
    ],
    model: 'openai'
  });
  return sock.sendMessage(chatId, { text: `📌 *${config.botName} - ${cmd.toUpperCase()}*\n\n${res.data}` }, { quoted: m });
}
