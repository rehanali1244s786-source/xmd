import axios from 'axios';
import sharp from 'sharp';
import config from '../../config.js';

const LANGUAGE_MAP = {
  hindi: 'hi', urdu: 'ur', arabic: 'ar', spanish: 'es', french: 'fr', german: 'de',
  chinese: 'zh-CN', japanese: 'ja', korean: 'ko', russian: 'ru', turkish: 'tr',
  italian: 'it', portuguese: 'pt', dutch: 'nl', polish: 'pl', swedish: 'sv',
  norwegian: 'no', danish: 'da', finnish: 'fi', greek: 'el', hebrew: 'iw',
  persian: 'fa', pashto: 'ps', punjabi: 'pa', sindhi: 'sd', bengali: 'bn',
  tamil: 'ta', telugu: 'te', marathi: 'mr', gujarati: 'gu', kannada: 'kn',
  malayalam: 'ml', nepali: 'ne', sinhala: 'si', thai: 'th', vietnamese: 'vi',
  indonesian: 'id', malay: 'ms', filipino: 'tl', swahili: 'sw', hausa: 'ha',
  yoruba: 'yo', igbo: 'ig', zulu: 'zu', amharic: 'am', somali: 'so', afrikaans: 'af'
};

export async function executeFunSuite(cmd, sock, m, ctx) {
  const { chatId, text, quotedText, senderJid, mentions } = ctx;
  const input = text || quotedText || config.botName;

  if (cmd.startsWith('translate')) {
    const langName = cmd.replace('translate', '').toLowerCase();
    const targetLang = LANGUAGE_MAP[langName] || 'en';
    if (!text && !quotedText) {
      return sock.sendMessage(chatId, { text: `🌍 Usage: \`${config.prefix}${cmd} <text>\` or reply to a message.` }, { quoted: m });
    }
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(input)}`;
    const { data } = await axios.get(url);
    const translated = data[0]?.map((item) => item[0]).join('') || input;
    return sock.sendMessage(
      chatId,
      { text: `🌍 *${config.botName} TRANSLATOR (${langName.toUpperCase()})*\n\n${translated}` },
      { quoted: m }
    );
  }

  if (cmd.endsWith('logo') || cmd.startsWith('3d')) {
    const displayTitle = (text || config.botName).slice(0, 28).replace(/[<>&"']/g, '');
    const styleName = cmd.replace(/logo$/, '').replace(/^3d/, '').replace(/text$/, '').toUpperCase();

    const svgImage = `
      <svg width="800" height="400" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#0b0719"/>
            <stop offset="50%" stop-color="#1e1136"/>
            <stop offset="100%" stop-color="#051d2d"/>
          </linearGradient>
          <linearGradient id="neon" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#00f2fe"/>
            <stop offset="50%" stop-color="#a855f7"/>
            <stop offset="100%" stop-color="#ec4899"/>
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="6" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        <rect width="100%" height="100%" fill="url(#bg)"/>
        <rect x="20" y="20" width="760" height="360" rx="24" fill="none" stroke="url(#neon)" stroke-width="4" opacity="0.6"/>
        <text x="50%" y="48%" dominant-baseline="middle" text-anchor="middle" fill="url(#neon)" font-family="Arial, sans-serif" font-weight="900" font-size="64" filter="url(#glow)">${displayTitle}</text>
        <text x="50%" y="78%" dominant-baseline="middle" text-anchor="middle" fill="#94a3b8" font-family="Arial, sans-serif" font-weight="600" font-size="20" letter-spacing="6">${config.botName} • ${styleName} STUDIO</text>
      </svg>`;

    const pngBuffer = await sharp(Buffer.from(svgImage)).png().toBuffer();
    return sock.sendMessage(
      chatId,
      { image: pngBuffer, caption: `✨ *${config.botName} LOGO STUDIO (${cmd.toUpperCase()})*\n🔤 *Text:* ${displayTitle}` },
      { quoted: m }
    );
  }

  const waifuEndpoints = ['waifu', 'neko', 'shinobu', 'megumin', 'awoo'];
  if (waifuEndpoints.includes(cmd)) {
    const { data } = await axios.get(`${config.apis.waifuPics}/sfw/${cmd}`);
    const imgBuf = await axios.get(data.url, { responseType: 'arraybuffer' });
    return sock.sendMessage(chatId, { image: Buffer.from(imgBuf.data), caption: `🌸 *${config.botName} - ${cmd.toUpperCase()}*` }, { quoted: m });
  }

  if (cmd.startsWith('anime') || ['naruto', 'sasuke', 'luffy', 'zoro', 'goku', 'vegeta', 'levi', 'eren', 'gojo', 'sukuna', 'tanjiro', 'nezuko', 'itachi', 'kakashi', 'madara', 'light', 'saitama', 'killua', 'anya', 'frieren'].includes(cmd)) {
    const query = cmd.startsWith('anime') ? (text || 'Naruto') : cmd;
    const { data } = await axios.get(`${config.apis.jikan}/characters?q=${encodeURIComponent(query)}&limit=1`);
    const char = data.data?.[0];
    if (char) {
      const imgBuf = await axios.get(char.images.jpg.image_url, { responseType: 'arraybuffer' });
      return sock.sendMessage(
        chatId,
        {
          image: Buffer.from(imgBuf.data),
          caption: `🎌 *${char.name}* (${char.name_kanji || ''})\n❤️ *Favorites:* ${char.favorites}\n\n${(char.about || '').slice(0, 500)}...`
        },
        { quoted: m }
      );
    }
  }

  if (['joke', 'dadjoke', 'pjoke', 'techjoke'].includes(cmd)) {
    const { data } = await axios.get('https://official-joke-api.appspot.com/random_joke');
    return sock.sendMessage(chatId, { text: `😂 *${config.botName} JOKE*\n\n*Q:* ${data.setup}\n*A:* _${data.punchline}_` }, { quoted: m });
  }

  if (cmd === 'memes' || cmd === 'dankmeme') {
    const { data } = await axios.get('https://meme-api.com/gimme');
    const imgBuf = await axios.get(data.url, { responseType: 'arraybuffer' });
    return sock.sendMessage(chatId, { image: Buffer.from(imgBuf.data), caption: `🤣 *${data.title}* (r/${data.subreddit})` }, { quoted: m });
  }

  if (cmd === 'dice') {
    return sock.sendMessage(chatId, { text: `🎲 *Dice Roll:* You rolled a *${Math.floor(Math.random() * 6) + 1}*!` }, { quoted: m });
  }
  if (cmd === 'coin') {
    return sock.sendMessage(chatId, { text: `🪙 *Coin Flip:* It landed on *${Math.random() < 0.5 ? 'HEADS' : 'TAILS'}*!` }, { quoted: m });
  }
  if (cmd === 'slots') {
    const icons = ['🍒', '🍋', '💎', '7️⃣', '🔔'];
    const r = [icons[Math.floor(Math.random() * 5)], icons[Math.floor(Math.random() * 5)], icons[Math.floor(Math.random() * 5)]];
    const win = r[0] === r[1] && r[1] === r[2];
    return sock.sendMessage(chatId, { text: `🎰 *SLOTS:* [ ${r.join(' | ')} ]\n${win ? '🎉 *JACKPOT WIN!*' : '😢 Try again!'}` }, { quoted: m });
  }
  if (cmd === 'lovetest' || cmd === 'ship' || cmd === 'compatibility') {
    const partner = mentions[0] || senderJid;
    const score = Math.floor(Math.random() * 101);
    return sock.sendMessage(
      chatId,
      { text: `💘 *${config.botName} COMPATIBILITY*\n@${senderJid.split('@')[0]} ❤️ @${partner.split('@')[0]}\n📊 *Score:* ${score}%`, mentions: [senderJid, partner] },
      { quoted: m }
    );
  }

  const res = await axios.post('https://text.pollinations.ai/', {
    messages: [
      { role: 'system', content: `You are ${config.botName} Entertainment & Games Engine on WhatsApp. Keep responses lively, formatted with emojis.` },
      { role: 'user', content: `Generate content for WhatsApp command ".${cmd}" ${text ? `with topic "${text}"` : ''}` }
    ],
    model: 'openai'
  });
  return sock.sendMessage(chatId, { text: `🎭 *${config.botName} - ${cmd.toUpperCase()}*\n\n${res.data}` }, { quoted: m });
}
