import axios from 'axios';
import yts from 'yt-search';
import config from '../../config.js';

export async function executeDownloaderSuite(cmd, sock, m, ctx) {
  const { chatId, text, args } = ctx;

  if (!text) {
    return sock.sendMessage(
      chatId,
      { text: `📥 *${config.botName} DOWNLOADER*\nUsage: \`${config.prefix}${cmd} <URL or search query>\`` },
      { quoted: m }
    );
  }

  await sock.sendMessage(chatId, { text: config.messages.wait }, { quoted: m });

  if (cmd.startsWith('yt') || cmd === 'mp3search' || cmd === 'mp4search') {
    const searchRes = await yts(text);
    const video = searchRes.videos?.[0];
    if (!video) {
      return sock.sendMessage(chatId, { text: '❌ No YouTube results found for your query.' }, { quoted: m });
    }

    if (cmd === 'ytthumb') {
      const thumbBuf = await axios.get(video.thumbnail, { responseType: 'arraybuffer' });
      return sock.sendMessage(
        chatId,
        { image: Buffer.from(thumbBuf.data), caption: `🖼️ *${video.title}*\n🔗 ${video.url}` },
        { quoted: m }
      );
    }

    const caption =
      `🎬 *${config.botName} - YOUTUBE (${cmd.toUpperCase()})*\n\n` +
      `📌 *Title:* ${video.title}\n` +
      `⏱️ *Duration:* ${video.timestamp}\n` +
      `👁️ *Views:* ${video.views.toLocaleString()}\n` +
      `👤 *Author:* ${video.author.name}\n` +
      `📅 *Uploaded:* ${video.ago}\n` +
      `🔗 *URL:* ${video.url}`;

    const thumbBuf = await axios.get(video.thumbnail, { responseType: 'arraybuffer' });
    return await sock.sendMessage(
      chatId,
      { image: Buffer.from(thumbBuf.data), caption },
      { quoted: m }
    );
  }

  if (cmd.startsWith('tiktok') || cmd === 'douyindl') {
    const res = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(text)}`, { timeout: 15000 });
    const data = res.data?.data;
    if (!data) {
      return sock.sendMessage(chatId, { text: '❌ Unable to fetch TikTok media. Ensure you provided a valid TikTok URL or keyword.' }, { quoted: m });
    }

    if (cmd === 'tiktokaudio' || cmd === 'tiktoksound') {
      const audioBuf = await axios.get(data.music, { responseType: 'arraybuffer' });
      return sock.sendMessage(chatId, { audio: Buffer.from(audioBuf.data), mimetype: 'audio/mp4' }, { quoted: m });
    }

    const videoBuf = await axios.get(data.play, { responseType: 'arraybuffer' });
    return sock.sendMessage(
      chatId,
      {
        video: Buffer.from(videoBuf.data),
        caption: `🎵 *${config.botName} TIKTOK DL*\n👤 *Author:* ${data.author?.nickname}\n📝 *Title:* ${data.title || 'TikTok Video'}`
      },
      { quoted: m }
    );
  }

  if (cmd === 'gitclonedl') {
    const match = text.match(/github\.com\/([^/]+)\/([^/\s]+)/i);
    if (!match) return sock.sendMessage(chatId, { text: '⚠️ Provide a valid GitHub repo URL.' }, { quoted: m });
    const [, user, repo] = match;
    const cleanRepo = repo.replace(/\.git$/, '');
    const zipUrl = `https://api.github.com/repos/${user}/${cleanRepo}/zipball`;
    const zipRes = await axios.get(zipUrl, { responseType: 'arraybuffer' });
    return sock.sendMessage(
      chatId,
      {
        document: Buffer.from(zipRes.data),
        fileName: `${cleanRepo}.zip`,
        mimetype: 'application/zip',
        caption: `📦 *${config.botName} GIT CLONE*\nRepo: ${user}/${cleanRepo}`
      },
      { quoted: m }
    );
  }

  if (cmd === 'npmdl') {
    const { data } = await axios.get(`https://registry.npmjs.org/${encodeURIComponent(args[0])}`);
    const latest = data['dist-tags']?.latest;
    const tarball = data.versions?.[latest]?.dist?.tarball;
    return sock.sendMessage(
      chatId,
      { text: `📦 *NPM PACKAGE: ${data.name}*\n🔢 *Version:* ${latest}\n📝 *Desc:* ${data.description}\n📥 *Tarball:* ${tarball}` },
      { quoted: m }
    );
  }

  if (cmd === 'pypidl') {
    const { data } = await axios.get(`https://pypi.org/pypi/${encodeURIComponent(args[0])}/json`);
    return sock.sendMessage(
      chatId,
      { text: `🐍 *PyPI PACKAGE: ${data.info.name}*\n🔢 *Version:* ${data.info.version}\n📝 *Summary:* ${data.info.summary}\n🔗 *URL:* ${data.info.package_url}` },
      { quoted: m }
    );
  }

  if (text.startsWith('http://') || text.startsWith('https://')) {
    const response = await axios.get(text, { responseType: 'arraybuffer', timeout: 20000, maxContentLength: 25 * 1024 * 1024 });
    const mime = response.headers['content-type'] || 'application/octet-stream';
    const buf = Buffer.from(response.data);

    if (mime.startsWith('image/')) {
      return sock.sendMessage(chatId, { image: buf, caption: `📥 Downloaded via *${config.botName}*` }, { quoted: m });
    }
    if (mime.startsWith('video/')) {
      return sock.sendMessage(chatId, { video: buf, caption: `📥 Downloaded via *${config.botName}*` }, { quoted: m });
    }
    if (mime.startsWith('audio/')) {
      return sock.sendMessage(chatId, { audio: buf, mimetype: 'audio/mp4' }, { quoted: m });
    }
    return sock.sendMessage(chatId, { document: buf, mimetype: mime, fileName: `dock_md_download` }, { quoted: m });
  }

  return sock.sendMessage(
    chatId,
    { text: `📥 *${config.botName} MEDIA HUB (${cmd.toUpperCase()})*\nQuery: *${text}*\nProvide a direct media URL to download the file directly into WhatsApp.` },
    { quoted: m }
  );
}
