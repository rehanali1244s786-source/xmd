import { downloadContentFromMessage, jidNormalizedUser } from '@whiskeysockets/baileys';
import axios from 'axios';
import sharp from 'sharp';
import config from '../../config.js';

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB Limit

async function downloadMediaBuffer(mediaMessage, mediaType) {
  const stream = await downloadContentFromMessage(mediaMessage, mediaType);
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function extractUrl(text) {
  if (!text) return null;
  const urlRegex = /(https?:\/\/[^\s]+)/gi;
  const matches = text.match(urlRegex);
  return matches ? matches[0] : null;
}

export default {
  name: 'dp',
  aliases: ['setdp', 'botdp', 'setppbot'],
  category: 'owner',
  description: 'Update DOCK MD profile picture by replying to an image, sticker, or link.',

  async execute(sock, m, { args }) {
    const chatId = m.key.remoteJid;

    try {
      const senderRaw = m.key.participant || m.key.remoteJid || '';
      const senderNumber = jidNormalizedUser(senderRaw).split('@')[0].split(':')[0];
      const isOwner = m.key.fromMe || config.owners.includes(senderNumber);

      if (!isOwner) {
        return await sock.sendMessage(
          chatId,
          { text: config.messages.ownerOnly },
          { quoted: m }
        );
      }

      const contextInfo =
        m.message?.extendedTextMessage?.contextInfo ||
        m.message?.imageMessage?.contextInfo ||
        null;

      const quotedMsg = contextInfo?.quotedMessage || null;

      const directImage = m.message?.imageMessage;
      const quotedImage = quotedMsg?.imageMessage || quotedMsg?.viewOnceMessageV2?.message?.imageMessage;
      const quotedSticker = quotedMsg?.stickerMessage;

      const quotedText =
        quotedMsg?.conversation ||
        quotedMsg?.extendedTextMessage?.text ||
        quotedMsg?.imageMessage?.caption ||
        quotedMsg?.videoMessage?.caption ||
        '';

      const targetUrl = extractUrl(quotedText) || extractUrl(args.join(' '));

      let rawBuffer = null;

      if (directImage) {
        const fileLength = Number(directImage.fileLength || 0);
        if (fileLength > MAX_FILE_SIZE) {
          throw new Error('Image size exceeds the 10MB maximum limit.');
        }
        rawBuffer = await downloadMediaBuffer(directImage, 'image');
      } else if (quotedImage) {
        const fileLength = Number(quotedImage.fileLength || 0);
        if (fileLength > MAX_FILE_SIZE) {
          throw new Error('Quoted image size exceeds the 10MB maximum limit.');
        }
        rawBuffer = await downloadMediaBuffer(quotedImage, 'image');
      } else if (quotedSticker) {
        if (quotedSticker.isAnimated) {
          throw new Error('Animated stickers cannot be set as a profile picture. Please reply to a static sticker or image.');
        }
        const fileLength = Number(quotedSticker.fileLength || 0);
        if (fileLength > MAX_FILE_SIZE) {
          throw new Error('Sticker size exceeds the 10MB maximum limit.');
        }
        rawBuffer = await downloadMediaBuffer(quotedSticker, 'sticker');
      } else if (targetUrl) {
        let parsedUrl;
        try {
          parsedUrl = new URL(targetUrl);
        } catch {
          throw new Error('Invalid URL format provided.');
        }

        const response = await axios.get(parsedUrl.href, {
          responseType: 'arraybuffer',
          timeout: 15000,
          maxContentLength: MAX_FILE_SIZE,
          maxBodyLength: MAX_FILE_SIZE,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) DOCK-MD/1.0'
          }
        });

        const contentType = response.headers['content-type'] || '';
        if (!contentType.startsWith('image/')) {
          throw new Error(`The provided link did not return a valid image (Detected: ${contentType || 'unknown'}).`);
        }

        rawBuffer = Buffer.from(response.data);
      } else {
        return await sock.sendMessage(
          chatId,
          {
            text:
              `⚠️ *${config.botName} - USAGE GUIDE*\n\n` +
              `Please reply to an *Image*, a *Static Sticker*, or a *Direct Image Link* with \`${config.prefix}dp\` to update the bot's profile picture.`
          },
          { quoted: m }
        );
      }

      if (!rawBuffer || rawBuffer.length === 0) {
        throw new Error('Failed to download media buffer (empty file).');
      }

      if (rawBuffer.length > MAX_FILE_SIZE) {
        throw new Error('Downloaded file exceeds the 10MB maximum limit.');
      }

      const processedJpegBuffer = await sharp(rawBuffer)
        .resize(640, 640, {
          fit: 'cover',
          position: 'center'
        })
        .jpeg({ quality: 90 })
        .toBuffer();

      const botJid = jidNormalizedUser(sock.user.id);
      await sock.updateProfilePicture(botJid, processedJpegBuffer);

      await sock.sendMessage(
        chatId,
        { text: '✅ Bot DP Updated Successfully!' },
        { quoted: m }
      );
    } catch (error) {
      let friendlyMessage = error.message || 'Failed to update Bot DP.';
      if (error.code === 'ERR_FR_MAX_BODY_LENGTH_EXCEEDED') {
        friendlyMessage = 'The image file at the link is too large (Max 10MB allowed).';
      } else if (error.code === 'ECONNABORTED' || error.code === 'ENOTFOUND') {
        friendlyMessage = 'Unable to reach the provided link. Please verify the URL is accessible.';
      }

      await sock.sendMessage(
        chatId,
        { text: config.messages.error(friendlyMessage) },
        { quoted: m }
      );
    }
  }
};
