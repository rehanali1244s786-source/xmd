import { jidNormalizedUser } from '@whiskeysockets/baileys';
import config from '../../config.js';
import { getGroupConfig, getUserData } from '../../lib/database.js';

const activeGiveaways = new Map();
const activePolls = new Map();

export async function executeGroupSuite(cmd, sock, m, ctx) {
  const { chatId, args, text, isGroup, senderJid, quotedParticipant, mentions } = ctx;

  if (!isGroup && !cmd.startsWith('poll') && !cmd.startsWith('giveaway') && !cmd.startsWith('raffle')) {
    return await sock.sendMessage(chatId, { text: config.messages.groupOnly }, { quoted: m });
  }

  let metadata = null;
  let participants = [];
  let admins = [];
  let isSenderAdmin = false;
  let isBotAdmin = false;

  if (isGroup) {
    metadata = await sock.groupMetadata(chatId);
    participants = metadata.participants || [];
    admins = participants.filter((p) => p.admin === 'admin' || p.admin === 'superadmin').map((p) => p.id);
    const botJid = jidNormalizedUser(sock.user.id);
    isSenderAdmin = admins.includes(senderJid) || ctx.isOwner;
    isBotAdmin = admins.includes(botJid);
  }

  const grpConfig = await getGroupConfig(chatId);
  const targetUser = quotedParticipant || mentions[0] || (args[0] ? `${args[0].replace(/[^0-9]/g, '')}@s.whatsapp.net` : null);

  if (cmd === 'tagall' || cmd === 'mentionlist' || cmd.startsWith('tag')) {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    let listToTag = participants.map((p) => p.id);
    if (cmd === 'tagadmins' || cmd === 'tagadminsilent' || cmd === 'admins') {
      listToTag = admins;
    } else if (cmd === 'tagrandom') {
      listToTag = [participants[Math.floor(Math.random() * participants.length)]?.id].filter(Boolean);
    } else if (cmd === 'tagowner' || cmd === 'tagcreator') {
      listToTag = [metadata.owner || admins[0]].filter(Boolean);
    }

    const header = `*📢 ${config.botName} - ${cmd.toUpperCase()}*\n` + (text ? `💬 *Message:* ${text}\n\n` : '\n');
    const body = listToTag.map((jid, i) => `${i + 1}. @${jid.split('@')[0]}`).join('\n');
    return await sock.sendMessage(chatId, { text: header + body, mentions: listToTag }, { quoted: m });
  }

  if (cmd === 'hidetag' || cmd === 'announce' || cmd === 'communityannounce') {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    const allIds = participants.map((p) => p.id);
    return await sock.sendMessage(chatId, { text: text || `📢 *Announcement from ${config.botName}*`, mentions: allIds }, { quoted: m });
  }

  if (cmd === 'kick' || cmd.startsWith('kick')) {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (!isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.botAdminRequired }, { quoted: m });

    if (cmd === 'kickall') {
      const nonAdmins = participants.filter((p) => !admins.includes(p.id)).map((p) => p.id);
      if (!nonAdmins.length) return sock.sendMessage(chatId, { text: 'ℹ️ No non-admin members to remove.' }, { quoted: m });
      await sock.groupParticipantsUpdate(chatId, nonAdmins, 'remove');
      return sock.sendMessage(chatId, { text: `✅ *${config.botName}* removed ${nonAdmins.length} members.` }, { quoted: m });
    }

    if (cmd === 'kickcountry' || cmd === 'kickprefix' || cmd === 'kickfake') {
      const prefixCode = (args[0] || '1').replace(/[^0-9]/g, '');
      const matching = participants
        .filter((p) => !admins.includes(p.id) && p.id.startsWith(prefixCode))
        .map((p) => p.id);
      if (!matching.length) return sock.sendMessage(chatId, { text: `ℹ️ No members found with prefix +${prefixCode}.` }, { quoted: m });
      await sock.groupParticipantsUpdate(chatId, matching, 'remove');
      return sock.sendMessage(chatId, { text: `✅ Removed ${matching.length} members with prefix +${prefixCode}.` }, { quoted: m });
    }

    if (!targetUser) return sock.sendMessage(chatId, { text: '⚠️ Mention or reply to a user to kick.' }, { quoted: m });
    await sock.groupParticipantsUpdate(chatId, [targetUser], 'remove');
    return sock.sendMessage(chatId, { text: `✅ Removed @${targetUser.split('@')[0]}`, mentions: [targetUser] }, { quoted: m });
  }

  if (cmd === 'add' || cmd.startsWith('add')) {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (!isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.botAdminRequired }, { quoted: m });
    if (!targetUser) return sock.sendMessage(chatId, { text: '⚠️ Provide a phone number to add (e.g. `.add 923001234567`).' }, { quoted: m });
    await sock.groupParticipantsUpdate(chatId, [targetUser], 'add');
    return sock.sendMessage(chatId, { text: `✅ Added @${targetUser.split('@')[0]}`, mentions: [targetUser] }, { quoted: m });
  }

  if (cmd === 'promote' || cmd === 'promoteall') {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (!isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.botAdminRequired }, { quoted: m });
    const targets = cmd === 'promoteall' ? participants.filter((p) => !admins.includes(p.id)).map((p) => p.id) : [targetUser].filter(Boolean);
    if (!targets.length) return sock.sendMessage(chatId, { text: '⚠️ Mention or reply to a user to promote.' }, { quoted: m });
    await sock.groupParticipantsUpdate(chatId, targets, 'promote');
    return sock.sendMessage(chatId, { text: `✅ Promoted ${targets.length} user(s) to Admin!`, mentions: targets }, { quoted: m });
  }

  if (cmd === 'demote' || cmd === 'demoteall') {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (!isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.botAdminRequired }, { quoted: m });
    const botJid = jidNormalizedUser(sock.user.id);
    const targets = cmd === 'demoteall' ? admins.filter((id) => id !== botJid && id !== senderJid) : [targetUser].filter(Boolean);
    if (!targets.length) return sock.sendMessage(chatId, { text: '⚠️ Mention or reply to a user to demote.' }, { quoted: m });
    await sock.groupParticipantsUpdate(chatId, targets, 'demote');
    return sock.sendMessage(chatId, { text: `✅ Demoted ${targets.length} user(s).`, mentions: targets }, { quoted: m });
  }

  if (['mute', 'lockgc', 'groupmute', 'lockdown', 'nightmode', 'autoclose'].includes(cmd)) {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (!isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.botAdminRequired }, { quoted: m });
    await sock.groupSettingUpdate(chatId, 'announcement');
    return sock.sendMessage(chatId, { text: `🔒 *${config.botName}:* Group is now locked (Admins Only).` }, { quoted: m });
  }

  if (['unmute', 'unlockgc', 'groupunmute', 'lockdownoff', 'nightmodeoff', 'autoopen'].includes(cmd)) {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (!isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.botAdminRequired }, { quoted: m });
    await sock.groupSettingUpdate(chatId, 'not_announcement');
    return sock.sendMessage(chatId, { text: `🔓 *${config.botName}:* Group is now open for all participants.` }, { quoted: m });
  }

  if (cmd === 'lockinfo') {
    if (!isSenderAdmin || !isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    await sock.groupSettingUpdate(chatId, 'locked');
    return sock.sendMessage(chatId, { text: '🔒 Group info editing restricted to Admins.' }, { quoted: m });
  }

  if (cmd === 'unlockinfo') {
    if (!isSenderAdmin || !isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    await sock.groupSettingUpdate(chatId, 'unlocked');
    return sock.sendMessage(chatId, { text: '🔓 Group info editing unlocked for all members.' }, { quoted: m });
  }

  if (cmd === 'setname') {
    if (!isSenderAdmin || !isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (!text) return sock.sendMessage(chatId, { text: '⚠️ Provide a new group name.' }, { quoted: m });
    await sock.groupUpdateSubject(chatId, text);
    return sock.sendMessage(chatId, { text: `✅ Group subject updated to: *${text}*` }, { quoted: m });
  }

  if (cmd === 'setdesc' || cmd === 'gcbio' || cmd === 'gcdescreset') {
    if (!isSenderAdmin || !isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    const newDesc = cmd === 'gcdescreset' ? '' : text;
    await sock.groupUpdateDescription(chatId, newDesc);
    return sock.sendMessage(chatId, { text: '✅ Group description updated!' }, { quoted: m });
  }

  if (['grouplink', 'invite', 'gcjoinlink', 'gcqr'].includes(cmd)) {
    if (!isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.botAdminRequired }, { quoted: m });
    const code = await sock.groupInviteCode(chatId);
    return sock.sendMessage(chatId, { text: `🔗 *${metadata.subject} Invite Link:*\nhttps://chat.whatsapp.com/${code}` }, { quoted: m });
  }

  if (cmd === 'resetlink') {
    if (!isSenderAdmin || !isBotAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    await sock.groupRevokeInvite(chatId);
    return sock.sendMessage(chatId, { text: '✅ Group invite link has been reset!' }, { quoted: m });
  }

  if (cmd.startsWith('gc') || ['members', 'online', 'offline', 'topactive', 'silentlist'].includes(cmd)) {
    const createdDate = new Date((metadata.creation || Date.now() / 1000) * 1000).toLocaleDateString();
    const ageDays = Math.floor((Date.now() - (metadata.creation || Date.now() / 1000) * 1000) / (1000 * 60 * 60 * 24));
    const infoText =
      `📊 *${config.botName} - GROUP ANALYTICS (${cmd.toUpperCase()})*\n\n` +
      `🏷️ *Name:* ${metadata.subject}\n` +
      `🆔 *JID:* ${chatId}\n` +
      `👑 *Owner:* ${metadata.owner ? '@' + metadata.owner.split('@')[0] : 'Hidden'}\n` +
      `👥 *Members:* ${participants.length}\n` +
      `🛡️ *Admins:* ${admins.length}\n` +
      `📅 *Created:* ${createdDate} (${ageDays} days old)\n` +
      `🔗 *Anti-Link:* ${grpConfig.antilink ? 'ON ✅' : 'OFF ❌'}\n` +
      `🛡️ *Anti-Spam:* ${grpConfig.antispam ? 'ON ✅' : 'OFF ❌'}\n` +
      `📝 *Description:* ${metadata.desc || 'None'}`;
    return sock.sendMessage(chatId, { text: infoText, mentions: metadata.owner ? [metadata.owner] : [] }, { quoted: m });
  }

  if (cmd.startsWith('anti') || cmd === 'addword' || cmd === 'delword' || cmd === 'listwords') {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });

    if (cmd === 'addword') {
      if (!text) return sock.sendMessage(chatId, { text: '⚠️ Specify a word to block.' }, { quoted: m });
      grpConfig.badWords.push(text.toLowerCase());
      await grpConfig.save();
      return sock.sendMessage(chatId, { text: `✅ Added *"${text}"* to the group filter list.` }, { quoted: m });
    }
    if (cmd === 'delword') {
      grpConfig.badWords = grpConfig.badWords.filter((w) => w !== text.toLowerCase());
      await grpConfig.save();
      return sock.sendMessage(chatId, { text: `✅ Removed *"${text}"* from the filter list.` }, { quoted: m });
    }
    if (cmd === 'listwords') {
      return sock.sendMessage(chatId, { text: `🚫 *Filtered Words:*\n${grpConfig.badWords.join(', ') || 'None'}` }, { quoted: m });
    }

    const toggleState = args[0] === 'off' ? false : args[0] === 'on' ? true : !grpConfig[cmd];
    if (cmd in grpConfig) {
      grpConfig[cmd] = toggleState;
    } else {
      grpConfig.antiFlags.set(cmd, toggleState);
    }
    await grpConfig.save();
    return sock.sendMessage(
      chatId,
      { text: `🛡️ *${config.botName} PROTECTION*\nModule *${cmd.toUpperCase()}* is now *${toggleState ? 'ENABLED ✅' : 'DISABLED ❌'}*` },
      { quoted: m }
    );
  }

  if (cmd.startsWith('warn') || cmd === 'unwarn' || cmd === 'resetwarn') {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (cmd === 'warnlimit') {
      const lim = parseInt(args[0], 10) || 3;
      grpConfig.warnLimit = lim;
      await grpConfig.save();
      return sock.sendMessage(chatId, { text: `✅ Group warning limit set to *${lim}*.` }, { quoted: m });
    }
    if (!targetUser) return sock.sendMessage(chatId, { text: '⚠️ Reply to or mention a user.' }, { quoted: m });
    const uData = await getUserData(targetUser);

    if (cmd === 'unwarn') {
      uData.warns = Math.max(0, uData.warns - 1);
      await uData.save();
      return sock.sendMessage(chatId, { text: `✅ Reduced warning for @${targetUser.split('@')[0]} (${uData.warns}/${grpConfig.warnLimit})`, mentions: [targetUser] }, { quoted: m });
    }
    if (cmd === 'resetwarn' || cmd === 'warnclear') {
      uData.warns = 0;
      uData.warnReasons = [];
      await uData.save();
      return sock.sendMessage(chatId, { text: `✅ Cleared all warnings for @${targetUser.split('@')[0]}`, mentions: [targetUser] }, { quoted: m });
    }

    uData.warns += 1;
    uData.warnReasons.push(text || 'Rule Violation');
    await uData.save();

    if (uData.warns >= grpConfig.warnLimit && isBotAdmin) {
      uData.warns = 0;
      await uData.save();
      await sock.groupParticipantsUpdate(chatId, [targetUser], 'remove');
      return sock.sendMessage(chatId, { text: `🚫 @${targetUser.split('@')[0]} reached ${grpConfig.warnLimit} warnings and was removed!`, mentions: [targetUser] }, { quoted: m });
    }
    return sock.sendMessage(
      chatId,
      { text: `⚠️ *WARNING ISSUED*\n👤 User: @${targetUser.split('@')[0]}\n🔢 Count: ${uData.warns}/${grpConfig.warnLimit}\n📝 Reason: ${text || 'Rule Violation'}`, mentions: [targetUser] },
      { quoted: m }
    );
  }

  if (cmd.startsWith('welcome') || cmd.startsWith('goodbye') || cmd === 'setwelcome' || cmd === 'setgoodbye') {
    if (!isSenderAdmin) return sock.sendMessage(chatId, { text: config.messages.adminOnly }, { quoted: m });
    if (cmd === 'setwelcome' || cmd === 'welcometext') {
      grpConfig.welcomeText = text || grpConfig.welcomeText;
      grpConfig.welcome = true;
    } else if (cmd === 'setgoodbye') {
      grpConfig.goodbyeText = text || grpConfig.goodbyeText;
      grpConfig.goodbye = true;
    } else if (cmd === 'welcomeoff') {
      grpConfig.welcome = false;
    } else if (cmd === 'goodbyeoff') {
      grpConfig.goodbye = false;
    } else {
      grpConfig.welcome = !grpConfig.welcome;
    }
    await grpConfig.save();
    return sock.sendMessage(chatId, { text: `✅ *${config.botName}:* Welcome/Goodbye configuration updated!` }, { quoted: m });
  }

  if (cmd === 'rules' || cmd === 'setrules' || cmd === 'clearrules') {
    if (cmd === 'setrules' && isSenderAdmin) {
      grpConfig.rules = text || 'Follow group guidelines.';
      await grpConfig.save();
      return sock.sendMessage(chatId, { text: '✅ Group rules updated!' }, { quoted: m });
    }
    if (cmd === 'clearrules' && isSenderAdmin) {
      grpConfig.rules = 'No specific rules set.';
      await grpConfig.save();
      return sock.sendMessage(chatId, { text: '✅ Group rules cleared.' }, { quoted: m });
    }
    return sock.sendMessage(chatId, { text: `📜 *${metadata?.subject || 'GROUP'} RULES*\n\n${grpConfig.rules}` }, { quoted: m });
  }

  if (cmd.startsWith('poll') || cmd.startsWith('vote')) {
    const parts = text.split('|').map((s) => s.trim()).filter(Boolean);
    const question = parts[0] || `Poll by ${config.botName}`;
    const options = parts.slice(1).length >= 2 ? parts.slice(1) : ['Yes ✅', 'No ❌', 'Maybe 🤔'];
    activePolls.set(chatId, { question, options, createdAt: Date.now() });
    return await sock.sendMessage(
      chatId,
      {
        poll: {
          name: question,
          values: options.slice(0, 12),
          selectableCount: 1
        }
      },
      { quoted: m }
    );
  }

  if (cmd.startsWith('giveaway') || cmd.startsWith('raffle')) {
    if (cmd === 'giveaway' || cmd === 'raffle' || cmd === 'giveawayprize') {
      const prize = text || 'VIP Mystery Prize 🎁';
      activeGiveaways.set(chatId, { prize, participants: new Set() });
      return sock.sendMessage(
        chatId,
        { text: `🎉 *${config.botName} GIVEAWAY STARTED!*\n🎁 *Prize:* ${prize}\n\nType \`${config.prefix}giveawayjoin\` to enter!` },
        { quoted: m }
      );
    }
    if (cmd === 'giveawayjoin' || cmd === 'raffleenter') {
      const gw = activeGiveaways.get(chatId);
      if (!gw) return sock.sendMessage(chatId, { text: '⚠️ No active giveaway in this chat. Start one with `.giveaway <prize>`.' }, { quoted: m });
      gw.participants.add(senderJid);
      return sock.sendMessage(chatId, { text: `✅ @${senderJid.split('@')[0]} entered the giveaway! (Total: ${gw.participants.size})`, mentions: [senderJid] }, { quoted: m });
    }
    if (['giveawayend', 'giveawaywinner', 'giveawayreroll', 'raffledraw'].includes(cmd)) {
      const gw = activeGiveaways.get(chatId);
      if (!gw || gw.participants.size === 0) {
        return sock.sendMessage(chatId, { text: '⚠️ No active giveaway or 0 participants.' }, { quoted: m });
      }
      const arr = Array.from(gw.participants);
      const winner = arr[Math.floor(Math.random() * arr.length)];
      return sock.sendMessage(
        chatId,
        { text: `🏆 *GIVEAWAY WINNER ANNOUNCEMENT*\n🎁 *Prize:* ${gw.prize}\n👑 *Winner:* @${winner.split('@')[0]}\nCongratulations! 🎉`, mentions: [winner] },
        { quoted: m }
      );
    }
  }

  if (cmd.startsWith('autoreply') || cmd.startsWith('filter')) {
    const [trigger, ...replyArr] = text.split('|').map((s) => s.trim());
    const responseText = replyArr.join('|');
    if (cmd.endsWith('add') && trigger && responseText) {
      grpConfig.autoReplies.set(trigger.toLowerCase(), responseText);
      await grpConfig.save();
      return sock.sendMessage(chatId, { text: `✅ Auto-reply trigger *"${trigger}"* saved!` }, { quoted: m });
    }
    if (cmd.endsWith('list')) {
      const keys = Array.from(grpConfig.autoReplies.keys());
      return sock.sendMessage(chatId, { text: `📋 *Active Triggers:*\n${keys.join(', ') || 'None'}` }, { quoted: m });
    }
  }

  return sock.sendMessage(
    chatId,
    { text: `✅ *${config.botName} GROUP ENGINE*\nExecuted *${config.prefix}${cmd}* successfully in *${metadata?.subject || 'Chat'}*.` },
    { quoted: m }
  );
}
